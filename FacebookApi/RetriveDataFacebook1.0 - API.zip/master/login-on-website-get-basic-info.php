<?php
session_start();
require_once __DIR__ . '/src/Facebook/autoload.php';

$fb = new Facebook\Facebook([
  'app_id' => '990807884348806',
  'app_secret' => '75623fb4313f49d32e9d0d331db57246',
  'default_graph_version' => 'v2.6',
  ]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email','user_birthday', 'user_location', 'user_website','user_friends', 'user_likes']; // optional
	
try {
	if (isset($_SESSION['facebook_access_token'])) {
		$accessToken = $_SESSION['facebook_access_token'];
	} else {
  		$accessToken = $helper->getAccessToken();
	}
} catch(Facebook\Exceptions\FacebookResponseException $e) {
 	// When Graph returns an error
 	echo 'Graph returned an error: ' . $e->getMessage();

  	exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
 	// When validation fails or other local issues
	echo 'Facebook SDK returned an error: ' . $e->getMessage();
  	exit;
 }

if (isset($accessToken)) {
	if (isset($_SESSION['facebook_access_token'])) {
		$fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
	} else {
		// getting short-lived access token
		$_SESSION['facebook_access_token'] = (string) $accessToken;

	  	// OAuth 2.0 client handler
		$oAuth2Client = $fb->getOAuth2Client();

		// Exchanges a short-lived access token for a long-lived one
		$longLivedAccessToken = $oAuth2Client->getLongLivedAccessToken($_SESSION['facebook_access_token']);

		$_SESSION['facebook_access_token'] = (string) $longLivedAccessToken;

		// setting default access token to be used in script
		$fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
	}
	/*
	// redirect the user back to the same page if it has "code" GET variable
	if (isset($_GET['code'])) {
		header('Location: ./');
	}
	*/
	// get data
	try {
		// getting basic info about user
		//$profile_request = $fb->get('/me?fields=name,first_name,last_name,email');
		$profile_request = $fb->get('/me?fields=name,first_name,last_name,birthday,website,location');
		$profile = $profile_request->getGraphNode()->asArray();
		// get list of friends' names
		$requestFriends = $fb->get('/me/taggable_friends?fields=name&limit=100');
		$friends = $requestFriends->getGraphEdge();
		// get list of pages liked by user
		$requestLikes = $fb->get('/me/likes?limit=100');
		$likes = $requestLikes->getGraphEdge();
		
		
	} catch(Facebook\Exceptions\FacebookResponseException $e) {
		// When Graph returns an error
		echo 'Graph returned an error: ' . $e->getMessage();
		session_destroy();
		// redirecting user back to app login page
		header("Location: ./");
		exit;
	} catch(Facebook\Exceptions\FacebookSDKException $e) {
		// When validation fails or other local issues
		echo 'Facebook SDK returned an error: ' . $e->getMessage();
		exit;
	}
	// printing data PROFILE on screen
	echo "PROFILE".'</br></br>';
	// printing $profile array on the screen which holds the basic info about user
	print_r($profile);
	//more specific
	echo "</br></br>SPECIFIC-PROFILE".'</br>';
	echo '</br></br>';
	echo $profile['birthday']->format('d-m-Y').'</br></br>';
	echo $profile['website'].'</br></br>';
	echo $profile['location']['name'].'</br></br>';

	// printing data FRIENDS on screen
	echo '</br></br>'."FRIENDS".'</br></br>';
	// if have more friends than 100 as we defined the limit above on line no. 63
	if ($fb->next($friends)) {
		$allFriends = array();
		$friendsArray = $friends->asArray();
		$allFriends = array_merge($friendsArray, $allFriends);
		while ($friends = $fb->next($friends)) {
			$friendsArray = $friends->asArray();
			$allFriends = array_merge($friendsArray, $allFriends);
		}
		foreach ($allFriends as $key) {
			echo $key['name'] . "<br>";
		}
		echo count($allfriends);
	} else {
		$allFriends = $friends->asArray();
		$totalFriends = count($allFriends);
		foreach ($allFriends as $key) {
			echo $key['name'] . "<br>";
		}
	}
	// printing data LIKE on screen
	echo '</br></br>'."LIKED_PAGES".'</br></br>';
	$totalLikes = array();
	if ($fb->next($likes)) {	
		$likesArray = $likes->asArray();
		$totalLikes = array_merge($totalLikes, $likesArray); 
		while ($likes = $fb->next($likes)) { 
			$likesArray = $likes->asArray();
			$totalLikes = array_merge($totalLikes, $likesArray);
		}
	} else {
		$likesArray = $likes->asArray();
		$totalLikes = array_merge($totalLikes, $likesArray);
	}

	// printing data on screen
	foreach ($totalLikes as $key) {
		echo $key['name'] . '<br>';
	}

  	// Now you can redirect to another page and use the access token from $_SESSION['facebook_access_token']
} else {
	// replace your website URL same as added in the developers.facebook.com/apps e.g. if you used http instead of https and you used non-www version or www version of your website then you must add the same here
	$loginUrl = $helper->getLoginUrl('http://localhost:8888/master/login-on-website-get-basic-info.php', $permissions);
	echo '<a href="' . $loginUrl . '">Log in with Facebook!</a>';
}
