<?php 

# http://localhost/test_site/php/test/fpdi.php

require("fpdf/fpdf.php");
require("fpdi/fpdi.php");

$numero = 1; 
for ($stampe=1 ; $stampe <= $numero ; $stampe++){ 

  $code = counter();

  $pdf = new FPDI(); 
//$pdf->AddPage('L');
  $NumeroPagine = $pdf->setSourceFile("fpdi_ddt.pdf");
  print "numero di pagine : ".$NumeroPagine."<br />";
 
  for($i = 1; $i <= $NumeroPagine; $i++){
    print "pagina : ".$i."  code : ".$code."<br />";

    $tplIdx = $pdf->importPage($i); 
    $s = $pdf->getTemplatesize($tplIdx);
//  $pdf->useTemplate($tplIdx, 0, 1, 300); 
    $pdf->AddPage($s['w'] > $s['h'] ? 'L' : 'P', array($s['w'], $s['h']));
    $pdf->useTemplate($tplIdx);

    $pdf->SetFont('Helvetica');		// now write some text above the imported page
    $pdf->SetFontSize(18); 
    $pdf->SetTextColor(196, 91, 106); 
    $pdf->SetXY(65, 43); 
    $pdf->Write(0, 'A'.$code); 
  } 
  $pdf->Output('fpdi_A'.$code.".pdf",'F'); 
} 
print "DONE !<br />";

function counter(){
  $var=@fopen("fpdi_code.txt",'r'); 
  $code=@fread($var,filesize("fpdi_code.txt")); 
  @fclose($var); 

  if ($code==null) $code=1; 
  else             $code=$code+1; 

  $var=@fopen("fpdi_code.txt",'w'); 
  @fwrite($var,$code); 
  @fclose($var); 

  return $code;
} 
?> 
