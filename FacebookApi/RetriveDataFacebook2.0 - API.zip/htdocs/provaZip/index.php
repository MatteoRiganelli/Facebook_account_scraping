<?php
require_once 'create_zip.php';

$files_to_zip = array(
	'1.jpg',
	'2.jpg'
);
//if true, good; if false, zip creation failed
$result = create_zip($files_to_zip,'my-archive.zip');
echo 'CREATO';

?>