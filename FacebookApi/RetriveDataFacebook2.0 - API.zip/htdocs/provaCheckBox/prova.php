<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="style.css">
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

</head>

<form action="gestire-checkbox.php" method="post">
	Quali informazioni desideri ottenere?
	
	<!--ID_PROFILO sempre attivo--> 		
					<input style="display: none" type="checkbox" name="piace[]" value="ID_PROFILO" checked> </br>
	NOME_COMPLETO   <input type="checkbox" name="piace[]" value="NOME_COMPLETO" /> </br>
	NOME 			<input type="checkbox" name="piace[]" value="NOME" /> </br>
	COGNOME 		<input type="checkbox" name="piace[]" value="COGNOME" /> </br>
	DATA_NASCITA 	<input type="checkbox" name="piace[]" value="DATA_NASCITA" /> </br>
	SITO_WEB 		<input type="checkbox" name="piace[]" value="SITO_WEB" /> </br>
	PAESE 			<input type="checkbox" name="piace[]" value="PAESE" /> </br>
	
	<input type="submit" value="Invia!">
	</form>



</html>



	
	



