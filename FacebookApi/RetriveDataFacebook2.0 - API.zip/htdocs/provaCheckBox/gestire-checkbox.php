<?php

$ID_PROFILO = 0;
$NOME_COMPLETO = 0;
$NOME = 0;
$COGNOME = 0;
$DATA_NASCITA = 0;
$SITO_WEB = 0;
$PAESE = 0;
var_dump($_POST['piace']);
if($_POST['piace']==NULL)
{ 
    //Vedo se ha cliccato su qualche checkbox;
    echo "Vai a farti un giro."; //In caso positivo lo mando a farsi un giro
}
else
{ 
	$piace = $_POST['piace']; //prendo i dati dal form
    $npiace = count ($piace); //Utilizzo count per contare il numero di valori contenuti nell'array
    for($i=0; $i < $npiace; $i++)
    {
        if($piace[$i] == 'ID_PROFILO')
        	$ID_PROFILO = 1;
        if($piace[$i] == 'NOME_COMPLETO')
        	$NOME_COMPLETO = 1;
        if($piace[$i] == 'NOME')
        	$NOME = 1;
        if($piace[$i] == 'COGNOME')
        	$COGNOME = 1;
        if($piace[$i] == 'DATA_NASCITA')
        	$DATA_NASCITA = 1;
        if($piace[$i] == 'SITO_WEB')
        	$SITO_WEB = 1;
        if($piace[$i] == 'PAESE')
        	$PAESE = 1;



        //echo('A te piace ' . $piace[$i] .' di InformaticaLab.');
    
    } 

    echo $ID_PROFILO;
    echo $NOME_COMPLETO;
    echo $NOME;
	echo $COGNOME;
	echo $DATA_NASCITA ;
	echo $SITO_WEB;
	echo $PAESE;

}
?>